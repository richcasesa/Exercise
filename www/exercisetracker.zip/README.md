Exercise
========